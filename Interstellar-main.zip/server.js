// Server-Sent Events (SSE) optimized for Render
app.get('/api/stream-logs', (req, res) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    const action = req.query.action;
    let cmd = '';

    // Render is pure Linux, use standard 'bash'
    // We point directly to the local directory where the files are pre-loaded
    if (action === 'open') {
        res.write("data: 🚀 Booting Interstellar Proxy Core...\n\n");
        cmd = `node index.js`; 
    } else if (action === 'refresh') {
        res.write("data: 🔄 Restarting Proxy Core Network...\n\n");
        cmd = `pkill -9 -f node || true; node index.js`;
    } else if (action === 'redeploy') {
        cmd = `node index.js`;
    } else {
        res.write("data: ❌ Unknown action\n\n");
        return res.end();
    }

    const child = spawn('bash', ['-c', cmd]);

    child.stdout.on('data', (data) => {
        res.write(`data: ${data.toString()}\n\n`);
    });

    child.stderr.on('data', (data) => {
        res.write(`data: ${data.toString()}\n\n`);
    });

    child.on('close', (code) => {
        res.write(`data: [PROCESS_EXITED_WITH_CODE_${code}]\n\n`);
        res.end();
    });
});
